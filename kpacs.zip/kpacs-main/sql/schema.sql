drop database kpacs;

create database kpacs;

use kpacs;

CREATE TABLE `kpacs`
(
    `kpac_id`      int(11)       NOT NULL AUTO_INCREMENT,
    `kpac_title`   varchar(250)  NOT NULL,
    `description`  varchar(2000) NOT NULL,
    `created_date` timestamp     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`kpac_id`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 25
  DEFAULT CHARSET = utf8;

CREATE TABLE `sets`
(
    `set_id`    int(11)      NOT NULL AUTO_INCREMENT,
    `set_title` varchar(250) NOT NULL,
    PRIMARY KEY (`set_id`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 25
  DEFAULT CHARSET = utf8;

CREATE TABLE `kpac_set`
(
    `kpac_id` int(11) not null,
    `set_id`  int(11) not null,
    PRIMARY KEY (`kpac_id`, `set_id`),
    CONSTRAINT `kpacs_SUB_ID_FK`
        FOREIGN KEY (`kpac_id`)
            REFERENCES `kpacs` (`kpac_id`),
    CONSTRAINT `sets_SUB_ID_FK`
        FOREIGN KEY (`set_id`)
            REFERENCES `sets` (`set_id`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 25
  DEFAULT CHARSET = utf8;
