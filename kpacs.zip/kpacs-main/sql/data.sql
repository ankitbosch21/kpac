insert into kpacs(kpac_id, kpac_title, description) value (1, 'KPAC1', 'description_1');
insert into kpacs(kpac_id, kpac_title, description) value (2, 'KPAC2', 'description_2');
insert into kpacs(kpac_id, kpac_title, description) value (3, 'KPAC3', 'description_3');

insert into sets(set_id, set_title) value (101, 'title1');
insert into sets(set_id, set_title) value (201, 'title2');
insert into sets(set_id, set_title) value (301, 'title3');

insert into kpac_set(kpac_id, set_id) value (1, 101);
insert into kpac_set(kpac_id, set_id) value (1, 201);
insert into kpac_set(kpac_id, set_id) value (2, 301);
