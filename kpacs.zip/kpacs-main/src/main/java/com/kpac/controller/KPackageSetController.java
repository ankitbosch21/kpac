package com.kpac.controller;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.kpac.dao.KPackageSetDAOImpl;
import com.kpac.model.KPackageSet;

@Controller
public class KPackageSetController {
    private final KPackageSetDAOImpl setDao;

    @Autowired
    public KPackageSetController(KPackageSetDAOImpl setDao) {
        this.setDao = setDao;
    }

    @GetMapping(value = "/sets")
    public ModelAndView listView(ModelAndView model) throws IOException {
        model.setViewName("sets");
        return model;
    }

    @GetMapping(value = "/sets/{setId}")
    public ModelAndView listSet(ModelAndView model, @PathVariable Long setId) throws IOException {
        model.setViewName("set");
        model.addObject("id", setId);
        return model;
    }

    @ResponseBody
    @GetMapping(value = "/api/sets", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<KPackageSet> loadAll() {
        return setDao.getAll();
    }

    @ResponseBody
    @GetMapping(value = "/api/sets/{setId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Optional<KPackageSet> get(@PathVariable long setId) {
        return setDao.get(setId);
    }

    @ResponseBody
    @PostMapping(value = "/api/sets", produces = MediaType.APPLICATION_JSON_VALUE)
    public KPackageSet save(@RequestBody KPackageSet set) {
        return setDao.save(set);
    }

    @ResponseBody
    @DeleteMapping(value = "/api/sets/{setId}")
    public void delete(@PathVariable long setId) {
        setDao.delete(setId);
    }
}
