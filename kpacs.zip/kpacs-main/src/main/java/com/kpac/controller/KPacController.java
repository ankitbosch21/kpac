package com.kpac.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.kpac.dao.KPackageDAOImpl;
import com.kpac.model.KPackage;

@Controller
public class KPacController {

    private final KPackageDAOImpl kPacDao;

    @Autowired
    public KPacController(KPackageDAOImpl kPacDao) {
        this.kPacDao = kPacDao;
    }

    @GetMapping(value = "/")
    public ModelAndView index(ModelAndView model) throws IOException {
        return new ModelAndView("redirect:/kpacs");
    }

    @GetMapping(value = "/kpacs")
    public ModelAndView listView(ModelAndView model) throws IOException {
        model.setViewName("kpacs");
        return model;
    }

    @ResponseBody
    @GetMapping(value = "/api/kpacs", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<KPackage> loadAll() {
        return kPacDao.getAll();
    }

    @ResponseBody
    @PostMapping(value = "/api/kpacs", produces = MediaType.APPLICATION_JSON_VALUE)
    public KPackage save(@RequestBody KPackage kpac) {
        return kPacDao.save(kpac);
    }

    @ResponseBody
    @DeleteMapping(value = "/api/kpacs/{kPacId}")
    public void delete(@PathVariable long kPacId) {
        kPacDao.delete(kPacId);
    }
}
