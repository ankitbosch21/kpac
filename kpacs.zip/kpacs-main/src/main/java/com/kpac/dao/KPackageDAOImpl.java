package com.kpac.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.kpac.model.KPackage;

@Repository
public class KPackageDAOImpl implements KPackageDAO<KPackage> {

    private final DataSource dataSource;
    private JdbcTemplate     jdbcTemplate;
    private SimpleJdbcInsert jdbcInsert;

    @Autowired
    public KPackageDAOImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @PostConstruct
    private void postConstruct() {
        jdbcTemplate = new JdbcTemplate(dataSource);
        jdbcInsert = new SimpleJdbcInsert(dataSource).withTableName("kpacs").usingGeneratedKeyColumns("kpac_id");
    }

    @Override
    public KPackage save(KPackage kpac) {
        SqlParameterSource parameters = new BeanPropertySqlParameterSource(kpac);
        jdbcInsert.execute(parameters);
        kpac.setKpacId(nextSequence());
        return kpac;
    }

    @Override
    public void delete(long id) {
        jdbcTemplate.update("delete from kpac_set where kpac_id = ?", id);
        jdbcTemplate.update("delete from kpacs where kpac_id = ?", id);
    }

    @Override
    public void update(KPackage kpac) {
        throw new UnsupportedOperationException();
    }

    private KPackage toKpac(ResultSet resultSet) throws SQLException {
        KPackage kpac = new KPackage();
        kpac.setKpacId(resultSet.getInt("kpac_id"));
        kpac.setKpacTitle(resultSet.getString("kpac_title"));
        kpac.setDescription(resultSet.getString("description"));
        kpac.setCreatedDate(resultSet.getDate("created_date"));
        return kpac;
    }

    private long nextSequence() {
        final SqlRowSet sqlRowSet = jdbcTemplate.queryForRowSet("select max(set_id) from sets;");
        sqlRowSet.next();
        return sqlRowSet.getLong(1);
    }

    @Override
    public Optional<KPackage> get(long id) {
        @SuppressWarnings("deprecation")
        List<KPackage> kPackages = jdbcTemplate.query("select * from kpacs where kpac_id =?", new Object[] { id },
                                                      (resultSet, i) -> toKpac(resultSet));

        if (kPackages.size() == 1) {
            return Optional.ofNullable(kPackages.get(0));
        }
        return null;
    }

    @Override
    public List<KPackage> getAll() {
        return jdbcTemplate.query("select * from kpacs", (resultSet, i) -> toKpac(resultSet));
    }
}