package com.kpac.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.TypeMismatchException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.kpac.model.KPackage;
import com.kpac.model.KPackageSet;

@Repository
public class KPackageSetDAOImpl implements KPackageDAO<KPackageSet> {
    private final DataSource                   dataSource;
    private JdbcTemplate                       jdbcTemplate;
    private SimpleJdbcInsert                   jdbcInsert;

    private static final String                INSERT_JOIN_QUERY = "insert into kpac_set(kpac_id, set_id) value (?, ?)";

    private static final String                SELECT_BY_ID      = "select k.kpac_id, k.kpac_title, k.description, "
                                                                   + "s.set_id, s.set_title from kpacs k join kpac_set ks "
                                                                   + "on k.kpac_id = ks.kpac_id right join sets s "
                                                                   + "on s.set_id = ks.set_id where s.set_id = ?";

    public final static RowMapper<KPackageSet> SET_MAPPER        = BeanPropertyRowMapper.newInstance(KPackageSet.class);
    public final static RowMapper<KPackage>    K_PAC_MAPPER      = BeanPropertyRowMapper.newInstance(KPackage.class);

    @Autowired
    public KPackageSetDAOImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @PostConstruct
    private void postConstruct() {
        jdbcTemplate = new JdbcTemplate(dataSource);
        jdbcInsert = new SimpleJdbcInsert(dataSource).withTableName("sets").usingGeneratedKeyColumns("set_id");
    }

    @Override
    public KPackageSet save(KPackageSet set) {
        SqlParameterSource parameters = new BeanPropertySqlParameterSource(set);
        jdbcInsert.execute(parameters);
        set.setSetId(nextSequence());
        set.getkPackageList().forEach(kPac -> jdbcTemplate.update(INSERT_JOIN_QUERY, kPac.getKpacId(), set.getSetId()));
        return set;
    }

    @Override
    public void delete(long id) {
        jdbcTemplate.update("delete from kpac_set where set_id = ?", id);
        jdbcTemplate.update("delete from sets where set_id = ?", id);
    }

    @Override
    public void update(KPackageSet set) {
        throw new UnsupportedOperationException();
    }

    private KPackageSet toSet(ResultSet resultSet) throws SQLException {
        KPackageSet packageSet = new KPackageSet();
        packageSet.setSetId(resultSet.getInt("set_id"));
        packageSet.setSetTitle(resultSet.getString("set_title"));
        return packageSet;
    }

    private long nextSequence() {
        final SqlRowSet sqlRowSet = jdbcTemplate.queryForRowSet("select max(set_id) from sets;");
        sqlRowSet.next();
        return sqlRowSet.getLong(1);
    }

    @Override
    public Optional<KPackageSet> get(long id) {
        return jdbcTemplate.query(SELECT_BY_ID, rs -> {
            KPackageSet packageSet = null;
            int row = 0;
            while (rs.next()) {
                if (packageSet == null) {
                    packageSet = SET_MAPPER.mapRow(rs, row);
                }
                try {
                    packageSet.addKPac(K_PAC_MAPPER.mapRow(rs, row));
                } catch (TypeMismatchException e) {

                }
                row++;
            }
            return Optional.ofNullable(packageSet);
        }, id);
    }

    @Override
    public List<KPackageSet> getAll() {
        return jdbcTemplate.query("select * from sets", (resultSet, i) -> toSet(resultSet));
    }

}