package com.kpac.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

public class KPackageSet {
	@JsonProperty("id")
	private long setId;
	@JsonProperty("title")
	private String setTitle;
	private List<KPackage> kPackageList = new ArrayList<>();

	public long getSetId() {
		return setId;
	}

	public void setSetId(long setId) {
		this.setId = setId;
	}

	public String getSetTitle() {
		return setTitle;
	}

	public void setSetTitle(String setTitle) {
		this.setTitle = setTitle;
	}

	public List<KPackage> getkPackageList() {
		return kPackageList;
	}

	public void setkPackageList(List<KPackage> kPackageList) {
		this.kPackageList = kPackageList;
	}

	public void addKPac(KPackage kPackage) {
		if (kPackage != null) {
			kPackageList.add(kPackage);
		}
	}
}
