package com.kpac.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;

public class KPackage {
	@JsonProperty("id")
	private long kpacId;
	@JsonProperty("title")
	private String kpacTitle;
	private String description;
	@JsonFormat(pattern = "DD-MM-YYYY")
	private Date createdDate = new Date();
	public long getKpacId() {
		return kpacId;
	}
	public void setKpacId(long kpacId) {
		this.kpacId = kpacId;
	}
	public String getKpacTitle() {
		return kpacTitle;
	}
	public void setKpacTitle(String kpacTitle) {
		this.kpacTitle = kpacTitle;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	
}
