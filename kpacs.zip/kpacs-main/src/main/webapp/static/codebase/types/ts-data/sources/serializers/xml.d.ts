import { IAnyObj } from "../../../ts-common/types";
export declare function jsonToXML(data: IAnyObj[], root?: string): string;
