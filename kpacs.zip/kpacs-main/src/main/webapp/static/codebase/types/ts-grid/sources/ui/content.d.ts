import { IContentList } from "../types";
export declare function getContent(): IContentList;
