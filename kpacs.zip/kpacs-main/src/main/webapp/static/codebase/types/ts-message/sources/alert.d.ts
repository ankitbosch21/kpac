import { IAlertProps } from "./types";
export declare function alert(props: IAlertProps): Promise<unknown>;
