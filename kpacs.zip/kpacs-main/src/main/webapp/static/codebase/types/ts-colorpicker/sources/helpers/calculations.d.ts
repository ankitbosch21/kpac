export declare function calculatePaletteGrip(clientRect: ClientRect, top: number, left: number): {
    s: number;
    v: number;
};
export declare function calculateRangeGrip(clientRect: ClientRect, left: number): {
    h: number;
    rangeLeft: number;
};
