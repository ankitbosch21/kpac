export declare function selectAllView(): any;
export declare function unselectAllView(): any;
export declare function emptyListView(value?: string): any;
export declare function emptyListHeight(value: string, width: number): number;
