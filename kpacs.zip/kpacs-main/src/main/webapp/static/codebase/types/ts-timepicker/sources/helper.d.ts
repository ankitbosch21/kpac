/**
 * This function is designed to resolve conflicts with the time setting for the 12 hour format.
 */
export declare function isTimeCheck(value: any): boolean;
