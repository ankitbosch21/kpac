# kpacs

#Prerequisite
- please update src/main/resources/application.properties before building the app
- jdbc.url=jdbc:mysql://localhost:3306/<db-name>
- jdbc.user.name=<db-user-name>
- jdbc.user.password=<db-user-password>

#For build the service
- mvn clean install
